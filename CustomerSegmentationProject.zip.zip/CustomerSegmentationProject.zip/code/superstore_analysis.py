# superstore_analysis.py
# Simple end-to-end: load -> clean -> basic EDA -> RFM -> KMeans clusters -> export CSV
# Save this file in the same folder as superstore.csv

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

sns.set(style="whitegrid")

# 1) LOAD FILE (tries CSV, then Excel)
try:
    df = pd.read_csv("superstore.csv", encoding='latin1')
    print("Loaded superstore.csv (CSV)")
except Exception as e:
    try:
        df = pd.read_excel("superstore.xlsx")
        print("Loaded superstore.xlsx (Excel)")
    except Exception as e2:
        print("ERROR: Could not find 'superstore.csv' or 'superstore.xlsx' in this folder.")
        raise

# 2) QUICK LOOK
print("\n--- First 5 rows ---")
print(df.head())

print("\n--- Columns ---")
print(df.columns.tolist())

print("\n--- Shape (rows,cols) ---")
print(df.shape)

print("\n--- Info ---")
df.info()

# 3) CLEANING
# Drop exact duplicate rows if any
df = df.drop_duplicates()

# Convert date columns to datetime (if they are strings)
# If conversion fails some rows become NaT; that's okay for now.
if 'Order Date' in df.columns:
    df['Order Date'] = pd.to_datetime(df['Order Date'], errors='coerce')
if 'Ship Date' in df.columns:
    df['Ship Date'] = pd.to_datetime(df['Ship Date'], errors='coerce')

# Check missing values
print("\n--- Missing values per column ---")
print(df.isnull().sum())

# 4) SIMPLE AGGREGATIONS (print results)
total_sales = df['Sales'].sum()
total_profit = df['Profit'].sum()
print(f"\nTotal Sales: Rs. {total_sales:,.2f}")
print(f"Total Profit: Rs. {total_profit:,.2f}")

print("\nSales by Category:")
print(df.groupby('Category')['Sales'].sum())

print("\nProfit by Region:")
print(df.groupby('Region')['Profit'].sum())

# Top 10 customers by sales
top_customers = df.groupby('Customer Name')['Sales'].sum().sort_values(ascending=False).head(10)
print("\nTop 10 customers by Sales:")
print(top_customers)

# 5) SAVE CLEANED CSV for Power BI or later use
cleaned_fname = "Cleaned_Superstore.csv"
df.to_csv(cleaned_fname, index=False)
print(f"\nCleaned dataset saved to {cleaned_fname}")

# 6) OPTIONAL: Simple plots (these will pop open windows)
try:
    plt.figure(figsize=(8,5))
    df.groupby('Category')['Sales'].sum().sort_values(ascending=False).plot(kind='bar')
    plt.title("Sales by Category")
    plt.ylabel("Sales")
    plt.tight_layout()
    plt.show()
except Exception as ex:
    print("Plotting error (ok to ignore if on headless machine):", ex)

# 7) RFM segmentation (simple)
if 'Customer ID' in df.columns and 'Order Date' in df.columns:
    snapshot_date = df['Order Date'].max() + pd.Timedelta(days=1)

    rfm = df.groupby('Customer ID').agg({
        'Order Date': lambda x: (snapshot_date - x.max()).days,
        'Order ID': 'nunique',
        'Sales': 'sum'
    }).reset_index()

    rfm.columns = ['Customer ID', 'Recency', 'Frequency', 'Monetary']

    # Replace NaNs (if any)
    rfm['Recency'] = rfm['Recency'].fillna(999)
    rfm['Frequency'] = rfm['Frequency'].fillna(0)
    rfm['Monetary'] = rfm['Monetary'].fillna(0)

    print("\nRFM sample:")
    print(rfm.head())

    # Scale and cluster with KMeans (2 or 3 clusters)
    from sklearn.preprocessing import StandardScaler
    from sklearn.cluster import KMeans

    X = rfm[['Recency', 'Frequency', 'Monetary']].copy()
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Quick elbow (optional) - comment out if slow
    # inertia = []
    # for k in range(1,6):
    #     km = KMeans(n_clusters=k, random_state=42)
    #     km.fit(X_scaled)
    #     inertia.append(km.inertia_)
    # print("Inertia values (k=1..5):", inertia)

    k = 3
    km = KMeans(n_clusters=k, random_state=42)
    rfm['Cluster'] = km.fit_predict(X_scaled)

    print("\nRFM clusters counts:")
    print(rfm['Cluster'].value_counts())

    # Save RFM clusters
    rfm.to_csv("rfm_segments.csv", index=False)
    print("Saved rfm_segments.csv")
else:
    print("RFM skipped: 'Customer ID' or 'Order Date' not found.")
